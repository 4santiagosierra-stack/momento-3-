Configuración de la Base de Datos

Crear la base de datos (CREATE DATABASE nombre_base_datos;)
Configurar credenciales en src/main/resources/application.properties (url, usuario, contraseña)
No subir credenciales reales al repo; usar variables de entorno
Ejecutar con mvn spring-boot:run

Manual de Integración para Frontend

Arquitectura: Frontend → API REST → Controller → Service → Repository → BD
Endpoints principales (GET, POST, PUT, DELETE en /api/recurso) manejados por RecursoController
Conectar desde el Frontend usando fetch() con JSON
Habilitar CORS si el Frontend corre en otro puerto

Integración Conceptual: Análisis de Datos

Se conecta al Backend consultando la BD y exponiendo resultados por un endpoint propio
Se conecta al Frontend igual que cualquier otro dato, pero alimentando gráficos o indicadores
Preguntas que responde: tendencias, valores máximos/mínimos, comportamientos atípicos, predicciones
Aporte: convierte datos crudos en información útil para tomar decisiones