package com.colegio.cole.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table (name = "estudiantes")
public class Estudiantes {
    @Id 
    @GeneratedValue (strategy = jakarta.persistence.GenerationType.IDENTITY)
    int id;
    @Column (name = "nombre", length = 100, nullable = false)
    String nombre;
    @Column (name = "grado", length = 100, nullable = false)
    String grado;
    @Column (name = "edad", length = 100, nullable = false)
    String edad;
    @Column (name = "notas", length = 100, nullable = false)
    String notas;
    public Estudiantes() {
    }
    public Estudiantes(int id, String nombre, String grado, String edad, String notas) {
        this.id = id;
        this.nombre = nombre;
        this.grado = grado;
        this.edad = edad;
        this.notas = notas;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getGrado() {
        return grado;
    }
    public void setGrado(String grado) {
        this.grado = grado;
    }
    public String getEdad() {
        return edad;
    }
    public void setEdad(String edad) {
        this.edad = edad;
    }
    public String getNotas() {
        return notas;
    }
    public void setNotas(String notas) {
        this.notas = notas;
    }
    public void grado() {
        System.out.println("El estudiante " + nombre + " está en el grado " + grado);
    }
    public void notas() {
        System.out.println("el estudiante"+ nombre + "tiene buenas natas");
    }
}
