package com.colegio.cole.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "biblioteca")
public class Biblioteca {
@Id 
@GeneratedValue (strategy = jakarta.persistence.GenerationType.IDENTITY)
    int id;
@Column (name = "nombre", length = 100, nullable = false)
    String nombre;
@Column (name = "tematica_libro", length = 100, nullable = false)
    String tematica_libro;
@Column (name = "prestar_libro", length = 100, nullable = false)
    String prestar_libro;
@Column (name = "bibliotecaria", length = 100, nullable = false)
    String bibliotecaria;
    public Biblioteca() {
    }
    public Biblioteca(int id, String nombre, String tematica_libro, String prestar_libro, String bibliotecaria) {
        this.id = id;
        this.nombre = nombre;
        this.tematica_libro = tematica_libro;
        this.prestar_libro = prestar_libro;
        this.bibliotecaria = bibliotecaria;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getTematica_libro() {
        return tematica_libro;
    }
    public void setTematica_libro(String tematica_libro) {
        this.tematica_libro = tematica_libro;
    }
    public String getPrestar_libro() {
        return prestar_libro;
    }
    public void setPrestar_libro(String prestar_libro) {
        this.prestar_libro = prestar_libro;
    }
    public String getBibliotecaria() {
        return bibliotecaria;
    }
    public void setBibliotecaria(String bibliotecaria) {
        this.bibliotecaria = bibliotecaria;
    }
    public void prestarLibro() {
        System.out.println("se presto el libro");
    }
public void devolverLibro() {
        System.out.println("se devolvio el libro");
    }
}