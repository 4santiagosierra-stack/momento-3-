package com.colegio.cole.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity 
@Table (name = "tienda")
public class Tienda {
    @Id
    @GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
    int id;
    @Column (name = "nombre", length = 100, nullable = false)
    String nombre;
    @Column (name = "productos", length = 100, nullable = false)
    String productos;
    @Column (name = "horario", length = 100, nullable = false)
    String horario;
    @Column (name = "encargado", length = 100, nullable = false)
    String encargado;
    @Column (name = "precios", length = 100, nullable = false)  
    String precios;
    public Tienda() {
    }
    public Tienda(int id, String nombre, String productos, String horario, String encargado, String precios) {
        this.id = id;
        this.nombre = nombre;
        this.productos = productos;
        this.horario = horario;
        this.encargado = encargado;
        this.precios = precios;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getProductos() {
        return productos;
    }
    public void setProductos(String productos) {
        this.productos = productos;
    }
    public String getHorario() {
        return horario;
    }
    public void setHorario(String horario) {
        this.horario = horario;
    }
    public String getEncargado() {
        return encargado;
    }
    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }
    public String getPrecios() {
        return precios;
    }
    public void setPrecios(String precios) {
        this.precios = precios;
    }


    
}
